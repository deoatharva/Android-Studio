package com.example.lispcompiler

class LispInterpreter {
    private val globalEnv = mutableMapOf<String, Any>()

    init {
        // Arithmetic operators
        globalEnv["+"] = { args: List<Any> -> args.sumOf { it as Int } }
        globalEnv["-"] = { args: List<Any> -> args.map { it as Int }.reduce { a, b -> a - b } }
        globalEnv["*"] = { args: List<Any> -> args.map { it as Int }.reduce { a, b -> a * b } }
        globalEnv["/"] = { args: List<Any> -> args.map { it as Int }.reduce { a, b -> a / b } }
        globalEnv["%"] = { args: List<Any> -> args.map { it as Int }.reduce { a, b -> a % b } }
        globalEnv["print"] = { args: List<Any> ->
            val output = args.joinToString(" ")
            println(output)
            output  // ✅ Return the printed value
        }


        // Comparison operators
        globalEnv["="] = { args: List<Any> -> if (args[0] == args[1]) 1 else 0 }
        globalEnv["!="] = { args: List<Any> -> if (args[0] != args[1]) 1 else 0 }
        globalEnv["<"] = { args: List<Any> -> if ((args[0] as Int) < (args[1] as Int)) 1 else 0 }
        globalEnv[">"] = { args: List<Any> -> if ((args[0] as Int) > (args[1] as Int)) 1 else 0 }
        globalEnv["<="] = { args: List<Any> -> if ((args[0] as Int) <= (args[1] as Int)) 1 else 0 }
        globalEnv[">="] = { args: List<Any> -> if ((args[0] as Int) >= (args[1] as Int)) 1 else 0 }
    }

    // Tokenizing input into individual symbols
    private fun tokenize(input: String): List<String> {
        return input.replace("(", " ( ")
            .replace(")", " ) ")
            .split("\\s+".toRegex())
            .filter { it.isNotEmpty() }
    }

    // Parsing tokens into an Abstract Syntax Tree (AST)
    private fun parse(tokens: MutableList<String>): Any {
        if (tokens.isEmpty()) throw IllegalArgumentException("Unexpected EOF")

        val token = tokens.removeAt(0)
        return when {
            token == "(" -> {
                val list = mutableListOf<Any>()
                while (tokens[0] != ")") {
                    list.add(parse(tokens))
                }
                tokens.removeAt(0) // Remove ')'
                list
            }
            token == ")" -> throw IllegalArgumentException("Unexpected ')'")

            // ✅ Handle strings (anything in double quotes)
            token.startsWith("\"") && token.endsWith("\"") -> token.substring(1, token.length - 1)

            // ✅ Convert numbers
            token.toIntOrNull() != null -> token.toInt()

            // ✅ Treat everything else as symbols (variable names or function names)
            else -> token
        }
    }

    // Evaluating the parsed Lisp expression
    private fun evaluate(expr: Any, env: MutableMap<String, Any> = globalEnv): Any {
        return when (expr) {
            is Int -> expr
            is String -> env[expr] ?: throw IllegalArgumentException("Undefined symbol: $expr")
            is List<*> -> {
                if (expr.isEmpty()) throw IllegalArgumentException("Empty expression")

                val op = expr[0] as String
                val args = expr.subList(1, expr.size)

                when (op) {
                    "define" -> {
                        val varName = args[0] as String
                        val value = evaluate(args[1]!!, env)
                        env[varName] = value
                        value
                    }
                    "if" -> {
                        val condition = evaluate(args[0]!!, env) as Int
                        if (condition != 0) evaluate(args[1]!!, env) else evaluate(args[2]!!, env)
                    }
                    "lambda" -> {
                        val params = args[0] as List<*>
                        val body = args[1]!!
                        return { arguments: List<Any> ->
                            val localEnv = env.toMutableMap()
                            for (i in params.indices) {
                                localEnv[params[i] as String] = arguments[i]
                            }
                            evaluate(body, localEnv)
                        }
                    }
                    else -> {
                        val func = env[op] ?: throw IllegalArgumentException("Unknown function: $op")

                        // ✅ Handle built-in functions
                        if (func is Function1<*, *>) {
                            val function = func as (List<Any>) -> Any
                            val evaluatedArgs = args.map { evaluate(it!!, env) }
                            return function(evaluatedArgs)
                        }

                        // ✅ If it's not a function, check if it's a value (string or integer)
                        if (func is String || func is Int) {
                            return func
                        }

                        throw IllegalArgumentException("Unknown function or value: $op")
                    }

                }
            }
            else -> throw IllegalArgumentException("Invalid expression")
        }
    }

    // Run Lisp code
    fun runLisp(code: String): Any {
        val tokens = tokenize(code)
        val parsedExpr = parse(tokens.toMutableList())
        val result = evaluate(parsedExpr)

        return if (result == "") "Execution Complete" else result
    }
}