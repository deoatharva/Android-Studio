package com.example.pycomp
import com.example.lispcompiler.LispInterpreter

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var inputField: EditText
    private lateinit var runButton: Button
    private lateinit var outputView: TextView
    private val interpreter = LispInterpreter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputField = findViewById(R.id.inputField)
        runButton = findViewById(R.id.runButton)
        outputView = findViewById(R.id.outputView)

        runButton.setOnClickListener {
            val code = inputField.text.toString()
            try {
                val result = interpreter.runLisp(code)
                outputView.text = "Output: $result"
            } catch (e: Exception) {
                outputView.text = "Error: ${e.message}"
            }
        }
    }
}