package com.example.activitiesandfragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class FragmentOne : Fragment(R.layout.activity_fragment_one) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val textView: TextView = view.findViewById(R.id.text_view)
        val button: Button = view.findViewById(R.id.button)

        textView.text = "This is Fragment One"

        button.setOnClickListener {
            Toast.makeText(requireContext(), "Fragment One", Toast.LENGTH_SHORT).show()
        }
    }
}