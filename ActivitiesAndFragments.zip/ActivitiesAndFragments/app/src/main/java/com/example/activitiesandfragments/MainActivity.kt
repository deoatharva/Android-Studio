package com.example.activitiesandfragments

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonFragmentOne: Button = findViewById(R.id.button_fragment_one)
        val buttonFragmentTwo: Button = findViewById(R.id.button_fragment_two)

        buttonFragmentOne.setOnClickListener {
            // Replace with Fragment One
            replaceFragment(FragmentOne())
        }

        buttonFragmentTwo.setOnClickListener {
            // Replace with Fragment Two
            replaceFragment(FragmentTwo())
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)  // Allow back navigation
        transaction.commit()
    }
}