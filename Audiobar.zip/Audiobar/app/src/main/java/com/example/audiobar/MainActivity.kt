package com.example.audiobar
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var playButton: Button
    private lateinit var seekBar: SeekBar
    private lateinit var currentPositionText: TextView
    private val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views
        playButton = findViewById(R.id.playButton)
        seekBar = findViewById(R.id.seekBar)
        currentPositionText = findViewById(R.id.currentPosition)

        // Set MediaPlayer and load the audio file from the raw folder
        mediaPlayer = MediaPlayer.create(this, R.raw.funk) // Load the audio from res/raw/fonk.mp3
        mediaPlayer.isLooping = false

        // Set the SeekBar max to the duration of the audio
        seekBar.max = mediaPlayer.duration

        // Update SeekBar while audio is playing
        val updateSeekBarRunnable = object : Runnable {
            override fun run() {
                seekBar.progress = mediaPlayer.currentPosition
                currentPositionText.text = formatDuration(mediaPlayer.currentPosition)
                handler.postDelayed(this, 1000)
            }
        }

        // Play button onClickListener
        playButton.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                playButton.text = "Play"
            } else {
                mediaPlayer.start()
                playButton.text = "Pause"
                handler.postDelayed(updateSeekBarRunnable, 0)
            }
        }

        // SeekBar change listener
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // When the audio finishes playing
        mediaPlayer.setOnCompletionListener {
            playButton.text = "Play"
            seekBar.progress = 0
            currentPositionText.text = formatDuration(0)
        }
    }

    // Format time in seconds to MM:SS format
    private fun formatDuration(duration: Int): String {
        val minutes = duration / 1000 / 60
        val seconds = (duration / 1000 % 60).toString().padStart(2, '0')
        return "$minutes:$seconds"
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release resources when the activity is destroyed
        mediaPlayer.release()
    }
}
