package com.example.form

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.widget.*
class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val etLoginUsername = findViewById<EditText>(R.id.etLoginUsername)
        val etLoginPassword = findViewById<EditText>(R.id.etLoginPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvUserDetails = findViewById<TextView>(R.id.tvUserDetails)

        val registeredName = intent.getStringExtra("name")
        val registeredAge = intent.getStringExtra("age")
        val registeredGender = intent.getStringExtra("gender")
        val registeredDob = intent.getStringExtra("dob")
        val registeredUsername = intent.getStringExtra("username")
        val registeredPassword = intent.getStringExtra("password")

        btnLogin.setOnClickListener {
            val inputUsername = etLoginUsername.text.toString()
            val inputPassword = etLoginPassword.text.toString()

            if (inputUsername == registeredUsername && inputPassword == registeredPassword) {
                val userDetails = "Name: $registeredName\nAge: $registeredAge\nGender: $registeredGender\nDOB: $registeredDob\nUsername: $registeredUsername"
                tvUserDetails.text = userDetails
                Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
