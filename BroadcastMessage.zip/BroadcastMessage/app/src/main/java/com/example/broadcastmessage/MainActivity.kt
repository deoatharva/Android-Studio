package com.example.marqueetext

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.broadcastmessage.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextMessage = findViewById<EditText>(R.id.editTextMessage)
        val editTextLocation = findViewById<EditText>(R.id.editTextLocation)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            val message = editTextMessage.text.toString().trim()
            val location = editTextLocation.text.toString().trim()

            if (message.isNotEmpty() && location.isNotEmpty()) {
                Toast.makeText(this, "Message: $message\nLocation: $location", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Please fill both fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
