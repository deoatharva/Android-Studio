package com.example.uielement

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val financialYearInput: EditText = findViewById(R.id.financialYearInput)
        val nameInput: EditText = findViewById(R.id.nameInput)
        val ageInput: EditText = findViewById(R.id.ageInput)
        val genderInput: EditText = findViewById(R.id.genderInput)
        val incomeInput: EditText = findViewById(R.id.incomeInput)
        val exemptIncomeInput: EditText = findViewById(R.id.exemptIncomeInput)
        val calculateButton: Button = findViewById(R.id.calculateButton)
        val reportOutput: TextView = findViewById(R.id.reportOutput)

        // Set button click listener for calculation
        calculateButton.setOnClickListener {
            // Fetch user input
            val financialYear = financialYearInput.text.toString().toInt()
            val assessmentYear = financialYear + 1
            val name = nameInput.text.toString()
            val age = ageInput.text.toString().toInt()
            val income = incomeInput.text.toString().toDouble()
            val exemptIncome = exemptIncomeInput.text.toString().toDouble()

            // Calculate income tax
            val taxableIncome = income - exemptIncome
            val tax = calculateIncomeTax(taxableIncome, age)

            // Generate report
            val report = """
                Name: $name
                Financial Year: $financialYear
                Assessment Year: $assessmentYear
                Taxable Income: $taxableIncome
                Income Tax Payable: $tax
            """.trimIndent()

            // Display report
            reportOutput.text = report
        }
    }

    // Function to calculate income tax based on taxable income and age
    private fun calculateIncomeTax(taxableIncome: Double, age: Int): Double {
        var tax = 0.0

        // Tax Slabs and Rates
        when {
            taxableIncome <= 250000 -> tax = 0.0
            taxableIncome <= 500000 -> tax = (taxableIncome - 250000) * 0.05
            taxableIncome <= 1000000 -> tax = (taxableIncome - 500000) * 0.20 + 12500  // Add tax from previous slab (₹12,500)
            else -> tax = (taxableIncome - 1000000) * 0.30 + 12500 + 100000  // Add tax from previous slabs (₹12,500 + ₹1,00,000)
        }

        // Rebate under Section 87A for income up to ₹5,00,000
        if (taxableIncome <= 500000) {
            tax = tax.coerceAtMost(12500.0)  // Max rebate of ₹12,500
        }

        // Senior Citizen Rebate (Optional: For age > 60 years, you can provide a 10% rebate or any special logic)
        if (age > 60) {
            tax *= 0.90  // For example, 10% tax rebate for senior citizens
        }

        return tax
    }

}