package com.example.pract1a

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.name)
        val age = findViewById<EditText>(R.id.age)
        val gender = findViewById<RadioGroup>(R.id.gender)
        val dob = findViewById<EditText>(R.id.dob)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val submitbtn = findViewById<Button>(R.id.submit)
        submitbtn.setOnClickListener{
            val name1 = name.text.toString()
            val age1 = age.text.toString()
            val selectGender = gender.checkedRadioButtonId
            val gender1 = if(selectGender != -1)findViewById<RadioButton>(selectGender).text.toString() else""
            val username1 = username.text.toString()
            val password1 = password.text.toString()
            if(name.isEmpty()){
                Toast.makeText(this,"all fields are required",Toast.LENGTH_SHORT).show()
            }else{
                val intent = Intent(this,LoginActivity)
            }
        }
    }
}